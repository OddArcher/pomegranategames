import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class BKGRND extends PApplet {

int nspeed = 30;
                  int nstart = 1;
                  int nsize = 1000;
                  int nrect = 0;
                  int nellipse = 0;
                  int ntriangle = 0;
                  int nline = 0;
                  int npoint = 0;
                  int nbackground1 = 0;
                  int nbackground2 = 0;
                  int nmonochrome = 0;
                  int ncolors = 1;
                  
                  public void setup(){
                    background(0,0,0);
                    frameRate(nspeed);
                    
                  }
                  
                  public void draw(){
                  text("Made By Ricky", 450, 980);
                  if(nstart == 1){
                    if(nmonochrome == 1){
                      if(nbackground1 == 1){
                        background(0,0,0);
                      }
                      stroke(random(255));
                      fill(random(255));
                      if(nrect == 1){
                        rect(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(nellipse == 1){
                        ellipse(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(ntriangle == 1){
                        triangle(random(nsize),random(nsize),random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(nline == 1){
                        line(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(npoint == 1){
                        point(random(nsize),random(nsize));
                      }
                      if(nbackground2 == 1){
                        background(0,0,0);
                      }
                    }
                    
                      if(ncolors == 1){
                      if(nbackground1 == 1){
                        background(0,0,0);
                      }
                      stroke(random(255),random(255),random(255));
                      fill(random(255),random(255),random(255));
                      if(nrect == 1){
                        rect(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(nellipse == 1){
                        ellipse(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(ntriangle == 1){
                        triangle(random(nsize),random(nsize),random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(nline == 1){
                        line(random(nsize),random(nsize),random(nsize),random(nsize));
                      }
                      if(npoint == 1){
                        point(random(nsize),random(nsize));
                      }
                      if(nbackground2 == 1){
                        background(0,0,0);
                      }
                    }
                  }  
                  }
                  
                  public void keyPressed() {
                    if(key == 'q' || key == 'Q'){
                      if(nrect == 1){
                        nrect = 0;
                      }
                      else {
                        nrect = 1;
                      }
                    }
                    if(key == 'w' || key == 'W'){
                      if(nellipse == 1){
                        nellipse = 0;
                      }
                      else {
                        nellipse = 1;
                      }
                    }
                    if(key == 'e' || key == 'E'){
                      if(ntriangle == 1){
                        ntriangle = 0;
                      }
                      else {
                        ntriangle = 1;
                      }
                    }
                    if(key == 'r' || key == 'R'){
                      if(nline == 1){
                        nline = 0;
                      }
                      else {
                        nline = 1;
                      }
                    }
                    if(key == 't' || key == 'T'){
                      if(npoint == 1){
                        npoint = 0;
                      }
                      else {
                        npoint = 1;
                      }
                    }
                    if(key == 'a' || key == 'A'){
                    if(nbackground1 == 1){
                        nbackground1 = 0;
                      }
                      else {
                        nbackground1 = 1;
                      }
                    }
                    if(key == 's' || key == 'S'){
                      if(nbackground2 == 1){
                        nbackground2 = 0;
                      }
                      else {
                        nbackground2 = 1;
                      }
                    }
                    if(key == 'd' || key == 'D'){
                      if(nstart == 1){
                        nstart = 0;
                      }
                      else {
                        nstart = 1;
                      }
                    }
                    if(key == 'z' || key == 'Z'){
                    ncolors = 1;
                    nmonochrome = 0;
                    }
                    if(key == 'x' || key == 'X'){
                    ncolors = 0;
                    nmonochrome = 1;
                    }
                  }
  public void settings() {  size(800,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "BKGRND" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
